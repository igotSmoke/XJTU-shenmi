#include "ray.h"

#include <cmath>
#include <array>

#include <Eigen/Dense>
#include <spdlog/spdlog.h>

#include "../utils/math.hpp"

using Eigen::Matrix3f;
using Eigen::Matrix4f;
using Eigen::Vector2f;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::numeric_limits;
using std::optional;
using std::size_t;

constexpr float infinity = 1e5f;
constexpr float eps      = 1e-5f;

Intersection::Intersection() : t(numeric_limits<float>::infinity()), face_index(0)
{
}

Ray generate_ray(int width, int height, int x, int y, Camera& camera, float depth)
{
    // these lines below are just for compiling and can be deleted
    (void)width;
    (void)height;
    (void)x;
    (void)y;
    (void)depth;
    // these lines above are just for compiling and can be deleted


    // The ratio between the specified plane (width x height)'s depth and the image plane's depth.
    
    // Transfer the view-space position to world space.
    Vector3f world_pos;
    return {camera.position, (world_pos - camera.position).normalized()};
}

optional<Intersection> ray_triangle_intersect(const Ray& ray, const GL::Mesh& mesh, size_t index)
{
    // these lines below are just for compiling and can be deleted
    (void)ray;
    (void)mesh;
    (void)index;
    // these lines above are just for compiling and can be deleted
    Intersection result;
    
    if (result.t - infinity < -eps) {
        return result;
    } else {
        return std::nullopt;
    }
}

optional<Intersection> naive_intersect(const Ray& ray, const GL::Mesh& mesh, const Matrix4f model)
{
    Intersection result;

    for (size_t i = 0; i < mesh.faces.count(); ++i) {
        Vector3f point_A = mesh.vertex(mesh.face(i)[0]);
        Vector3f point_B = mesh.vertex(mesh.face(i)[1]);
        Vector3f point_C = mesh.vertex(mesh.face(i)[2]);

        Vector4f point_A4 = {point_A[0], point_A[1], point_A[2], 1.0f};
        Vector4f point_B4 = {point_B[0], point_B[1], point_B[2], 1.0f};
        Vector4f point_C4 = {point_C[0], point_C[1], point_C[2], 1.0f};

        point_A4 = model * point_A4;
        point_B4 = model * point_B4;
        point_C4 = model * point_C4;

        point_A[0] = point_A4[0];
        point_A[1] = point_A4[1];
        point_A[2] = point_A4[2];
        point_B[0] = point_B4[0];
        point_B[1] = point_B4[1];
        point_B[2] = point_B4[2];
        point_C[0] = point_C4[0];
        point_C[1] = point_C4[1];
        point_C[2] = point_C4[2];

        Vector3f point_origin = ray.origin;
        Vector3f direction    = ray.direction;

        Vector3f A_sub_B = point_A - point_B;
        Vector3f A_sub_C = point_A - point_C;

        Matrix3f matrix_solve = Matrix3f::Identity();

        matrix_solve.col(0) = direction;
        matrix_solve.col(1) = A_sub_B;
        matrix_solve.col(2) = A_sub_C;

        if (matrix_solve.determinant() == 0) // 平行
            continue;

        Vector3f x_solve = matrix_solve.inverse() * (point_A - point_origin);

        if (x_solve[0] > 0 && x_solve[1] > 0 && x_solve[2] > 0 && x_solve[0] < 1 &&
            x_solve[1] < 1 && x_solve[2] < 1) {
            Vector3f x   = x_solve[0] * point_A + x_solve[1] * point_B + x_solve[2] * point_C;
            float t_temp = (x - point_origin)[0] / direction[0];
            if (t_temp > eps) {

                if (result.t > t_temp) {
                    result.barycentric_coord = x_solve;
                    result.face_index        = i;
                    result.t                 = t_temp;
                }
            }
        }
        // Vertex a, b and c are assumed to be in counterclockwise order.
        // Construct matrix A = [d, a - b, a - c] and solve Ax = (a - origin)
        // Matrix A is not invertible, indicating the ray is parallel with the triangle.
        // Test if alpha, beta and gamma are all between 0 and 1.
    }
    // Ensure result.t is strictly less than the constant `infinity`.
    if (result.t - infinity < -eps) {
        return result;
    }
    return std::nullopt;
}
