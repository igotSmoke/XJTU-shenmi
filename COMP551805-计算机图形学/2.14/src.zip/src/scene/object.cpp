#include "object.h"

#include <array>
#include <optional>

#ifdef _WIN32
#include <Windows.h>
#endif
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <fmt/format.h>

#include "../utils/math.hpp"
#include "../utils/ray.h"
#include "../simulation/solver.h"
#include "../utils/logger.h"

using Eigen::Matrix4f;
using Eigen::Quaternionf;
using Eigen::Vector3f;
using std::array;
using std::make_unique;
using std::optional;
using std::string;
using std::vector;

bool Object::BVH_for_collision   = false;
size_t Object::next_available_id = 0;
std::function<KineticState(const KineticState&, const KineticState&)> Object::step =
    forward_euler_step;

Object::Object(const string& object_name)
    : name(object_name), center(0.0f, 0.0f, 0.0f), scaling(1.0f, 1.0f, 1.0f),
      rotation(1.0f, 0.0f, 0.0f, 0.0f), velocity(0.0f, 0.0f, 0.0f), force(0.0f, 0.0f, 0.0f),
      mass(1.0f), BVH_boxes("BVH", GL::Mesh::highlight_wireframe_color)
{
    visible  = true;
    modified = false;
    id       = next_available_id;
    ++next_available_id;
    bvh                      = make_unique<BVH>(mesh);
    const string logger_name = fmt::format("{} (Object ID: {})", name, id);
    logger                   = get_logger(logger_name);
}

Matrix4f Object::model()
{
    // 根据物体的center,rotation和scaling三个属性计算出model matrix，其中center scaling
    // 均为Vector3f，rotation则需转化为欧拉角
    auto [x_angle, y_angle, z_angle] =
        quaternion_to_ZYX_euler(rotation.w(), rotation.x(), rotation.y(), rotation.z());
    x_angle = radians(x_angle);
    y_angle = radians(y_angle);
    z_angle = radians(z_angle);

    Matrix4f scalingMatrix = Matrix4f::Identity();
    scalingMatrix(0, 0)    = scaling.x();
    scalingMatrix(1, 1)    = scaling.y();
    scalingMatrix(2, 2)    = scaling.z(); // 缩放矩阵完成

    Matrix4f rx4f = Matrix4f::Identity();
    rx4f(1, 1)    = cos(x_angle);
    rx4f(1, 2)    = -1 * sin(x_angle);
    rx4f(2, 1)    = sin(x_angle);
    rx4f(2, 2)    = cos(x_angle);

    Matrix4f ry4f = Matrix4f::Identity();
    ry4f(0, 0)    = cos(y_angle);
    ry4f(0, 2)    = sin(y_angle);
    ry4f(2, 0)    = -1 * sin(y_angle);
    ry4f(2, 2)    = cos(y_angle);

    Matrix4f rz4f = Matrix4f::Identity();
    rz4f(0, 0)    = cos(z_angle);
    rz4f(0, 1)    = -1 * sin(z_angle);
    rz4f(1, 0)    = sin(z_angle);
    rz4f(1, 1)    = cos(z_angle);

    Matrix4f rotationMatrix = rx4f * ry4f * rz4f;

    Matrix4f translationMatrix = Matrix4f::Identity();
    translationMatrix(0, 3)    = center.x();
    translationMatrix(1, 3)    = center.y();
    translationMatrix(2, 3)    = center.z();

    Matrix4f modelMatrix = Matrix4f::Identity();
    modelMatrix          = translationMatrix * rotationMatrix * scalingMatrix;

    return modelMatrix;
}

void Object::update(vector<Object*>& all_objects)
{
    // 首先调用 step 函数计下一步该物体的运动学状态。
    KineticState current_state{center, velocity, force / mass};
    KineticState next_state = step(prev_state, current_state);
    center                  = next_state.position;
    // velocity                = next_state.velocity;

    // 将物体的位置移动到下一步状态处，但暂时不要修改物体的速度。
    // 遍历 all_objects，检查该物体在下一步状态的位置处是否会与其他物体发生碰撞。
    bool if_coop = false;
    for (auto object : all_objects) {
        if (id == object->id && name == object->name)
            continue;

        Intersection coop_result;
        for (size_t i = 0; i < mesh.edges.count(); ++i) {
            array<size_t, 2> v_indices = mesh.edge(i);
            Vector3f point_1           = mesh.vertex(v_indices[0]);
            Vector3f point_2           = mesh.vertex(v_indices[1]);
            Eigen::Vector4f point_14   = {point_1[0], point_1[1], point_1[2], 1.0f};
            Eigen::Vector4f point_24   = {point_2[0], point_2[1], point_2[2], 1.0f};
            point_14                   = model() * point_14;
            point_24                   = model() * point_24;
            point_1[0]                 = point_14[0];
            point_1[1]                 = point_14[1];
            point_1[2]                 = point_14[2];
            point_2[0]                 = point_24[0];
            point_2[1]                 = point_24[1];
            point_2[2]                 = point_24[2];

            Ray ray1to2;
            ray1to2.origin    = point_1;
            ray1to2.direction = point_2 - point_1;
            optional<Intersection> result1to2 =
                naive_intersect(ray1to2, object->mesh, object->model());

            Ray ray2to1;
            ray2to1.origin    = point_2;
            ray2to1.direction = point_1 - point_2;
            optional<Intersection> result2to1 =
                naive_intersect(ray2to1, object->mesh, object->model());

            Intersection result21;
            Intersection result12;

            if (result2to1.has_value()) {
                result21 = result2to1.value();
                if (result21.t <= 1 && result21.t > 0) {
                    coop_result = result21;
                    if_coop     = true;
                    break;
                }
            }
            if (result1to2.has_value()) {
                result12 = result1to2.value();
                if (result12.t <= 1 && result12.t > 0) {
                    coop_result = result12;
                    if_coop     = true;
                    break;
                }
            }
        }

        if (if_coop) {
            // logger->info("bei zhuang de ID: {}", object->id);
            // logger->info("beizhuang mian ID: {}", coop_result.face_index);
            Vector3f point_A = object->mesh.vertex(object->mesh.face(coop_result.face_index)[0]);
            Vector3f point_B = object->mesh.vertex(object->mesh.face(coop_result.face_index)[1]);
            Vector3f point_C = object->mesh.vertex(object->mesh.face(coop_result.face_index)[2]);

            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_A[0], point_A[1], point_A[2]);
            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_B[0], point_B[1], point_B[2]);
            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_C[0], point_C[1], point_C[2]);

            Eigen::Vector4f point_A4 = {point_A[0], point_A[1], point_A[2], 1.0f};
            Eigen::Vector4f point_B4 = {point_B[0], point_B[1], point_B[2], 1.0f};
            Eigen::Vector4f point_C4 = {point_C[0], point_C[1], point_C[2], 1.0f};

            point_A4 = object->model() * point_A4;
            point_B4 = object->model() * point_B4;
            point_C4 = object->model() * point_C4;

            point_A[0] = point_A4[0];
            point_A[1] = point_A4[1];
            point_A[2] = point_A4[2];
            point_B[0] = point_B4[0];
            point_B[1] = point_B4[1];
            point_B[2] = point_B4[2];
            point_C[0] = point_C4[0];
            point_C[1] = point_C4[1];
            point_C[2] = point_C4[2];

            Vector3f A_sub_B = point_A - point_B;
            Vector3f A_sub_C = point_A - point_C;
            Vector3f n       = A_sub_B.cross(A_sub_C);
            n                = n.normalized();

            Vector3f v1_sub_v2 = object->velocity - velocity;
            float Jr         = 2 * v1_sub_v2.dot(n) * (mass * object->mass) / (mass + object->mass);
            velocity         = velocity + (Jr / mass) * n;
            object->velocity = object->velocity - (Jr / object->mass) * n;
            object->center   = object->prev_state.position;

            // logger->info("faxiangliang: (x: {}, y: {}, z: {})", n[0], n[1], n[2]);
            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_A[0], point_A[1], point_A[2]);
            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_B[0], point_B[1], point_B[2]);
            // logger->info("Vector3f: (x: {}, y: {}, z: {})", point_C[0], point_C[1], point_C[2]);

            center = current_state.position;

            break;
        }
    }
    prev_state = current_state;
    if (!if_coop)
        velocity = next_state.velocity;
}

void Object::render(const Shader& shader, WorkingMode mode, bool selected)
{
    if (modified) {
        mesh.VAO.bind();
        mesh.vertices.to_gpu();
        mesh.normals.to_gpu();
        mesh.edges.to_gpu();
        mesh.edges.release();
        mesh.faces.to_gpu();
        mesh.faces.release();
        mesh.VAO.release();
    }
    modified = false;
    // Render faces anyway.
    unsigned int element_flags = GL::Mesh::faces_flag;
    if (mode == WorkingMode::MODEL) {
        // For *Model* mode, only the selected object is rendered at the center in the world.
        // So the model transform is the identity matrix.
        shader.set_uniform("model", I4f);
        shader.set_uniform("normal_transform", I4f);
        element_flags |= GL::Mesh::vertices_flag;
        element_flags |= GL::Mesh::edges_flag;
    } else {
        Matrix4f model = this->model();
        shader.set_uniform("model", model);
        shader.set_uniform("normal_transform", (Matrix4f)(model.inverse().transpose()));
    }
    // Render edges of the selected object for modes with picking enabled.
    if (check_picking_enabled(mode) && selected) {
        element_flags |= GL::Mesh::edges_flag;
    }
    mesh.render(shader, element_flags);
}

void Object::rebuild_BVH()
{
    bvh->recursively_delete(bvh->root);
    bvh->build();
    BVH_boxes.clear();
    refresh_BVH_boxes(bvh->root);
    BVH_boxes.to_gpu();
}

void Object::refresh_BVH_boxes(BVHNode* node)
{
    if (node == nullptr) {
        return;
    }
    BVH_boxes.add_AABB(node->aabb.p_min, node->aabb.p_max);
    refresh_BVH_boxes(node->left);
    refresh_BVH_boxes(node->right);
}
