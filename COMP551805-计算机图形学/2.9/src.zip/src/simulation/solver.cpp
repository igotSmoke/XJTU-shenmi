#include "solver.h"

#include <Eigen/Core>

using Eigen::Vector3f;

// External Force does not changed.

// Function to calculate the derivative of KineticState
KineticState derivative(const KineticState& state)
{
    return KineticState(state.velocity, state.acceleration, Eigen::Vector3f(0, 0, 0));
}

// Function to perform a single Forward Euler step
KineticState forward_euler_step([[maybe_unused]] const KineticState& previous,
                                const KineticState& current)
{
    KineticState new_state;
    new_state.acceleration = current.acceleration;
    new_state.velocity     = current.velocity + current.acceleration * time_step;
    new_state.position     = current.position + current.velocity * time_step;

    return new_state;
}

// Function to perform a single Runge-Kutta step
KineticState runge_kutta_step([[maybe_unused]] const KineticState& previous,
                              const KineticState& current)
{
    KineticState new_state;
    new_state.acceleration = current.acceleration;

    // 中间变量，用于存储RK4过程中的斜率（导数）

    Vector3f k1 = current.velocity;

    Vector3f k2 = current.velocity + 0.5 * time_step * current.acceleration;

    Vector3f k3 = current.velocity + 0.5 * time_step * current.acceleration;

    Vector3f k4 = current.velocity + time_step * current.acceleration;

    new_state.velocity = current.velocity + time_step * current.acceleration;

    new_state.position = current.position + (time_step / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4);

    return new_state;
}

// Function to perform a single Backward Euler step
KineticState backward_euler_step([[maybe_unused]] const KineticState& previous,
                                 const KineticState& current)
{
    KineticState new_state;
    new_state.acceleration = current.acceleration;
    new_state.velocity     = current.velocity + current.acceleration * time_step;
    new_state.position     = current.position + new_state.velocity * time_step;

    return new_state;
}

// Function to perform a single Symplectic Euler step
KineticState symplectic_euler_step(const KineticState& previous, const KineticState& current)
{
    (void)previous;
    KineticState new_state;
    new_state.acceleration = current.acceleration;
    new_state.velocity     = current.velocity + current.acceleration * time_step;
    new_state.position     = current.position + new_state.velocity * time_step;

    return new_state;
}
